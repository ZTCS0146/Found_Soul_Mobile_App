package com.example.fsdfsdfs

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
