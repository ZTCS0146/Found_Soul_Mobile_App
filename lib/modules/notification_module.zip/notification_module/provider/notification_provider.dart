import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class NotificationProvider extends ChangeNotifier {
 

  // Validation status (optional if you want UI state management)
  bool isLoading = false;
  bool isSignOutLoading = false;
  // Dispose method

 
  
  }

   
  
